import React,{useEffect,useRef,useState} from 'react';
import{createRoot}from'react-dom/client';
import{Capacitor}from'@capacitor/core';
import{CapacitorSQLite,SQLiteConnection}from'@capacitor-community/sqlite';
import * as XLSX from'xlsx';
import{Share}from'@capacitor/share';
import{Filesystem,Directory,Encoding}from'@capacitor/filesystem';
import{Home,Upload,PlusCircle,GitCompare,Search,ShieldCheck,Car,Database,Download,Trash2,RefreshCw,FileSpreadsheet,MapPin,History,CheckCircle2,AlertTriangle}from'lucide-react';
import'./style.css';

/* ============================================================
   طبقة التخزين: SQLite أصلي على Android فقط.
   مصممة لمئات الآلاف من اللوحات: لا يتم تحميل القاعدة كاملة في الذاكرة،
   كل العرض والإحصاءات والبحث بتتم باستعلامات SQL مرقّمة.
   ============================================================ */
const DB_NAME='plates_v2';
const STAGE=100;          // base_id مؤقت للاستيراد (يتم استبدال القاعدة بعد اكتمال الاستيراد فقط)
const BATCH=100;         // عدد الصفوف في كل دفعة كتابة
const PAGE_SIZE=25;
const MAX_XLSX=8*1024*1024; // Excel أكبر من كده بيستهلك ذاكرة كبيرة؛ استخدم CSV

const sqlite=new SQLiteConnection(CapacitorSQLite);
let dbPromise=null;

const SCHEMA=`
CREATE TABLE IF NOT EXISTS plates (base_id INTEGER NOT NULL, pkey TEXT NOT NULL, original TEXT NOT NULL DEFAULT '', street TEXT NOT NULL DEFAULT '', link TEXT NOT NULL DEFAULT '', vtype TEXT NOT NULL DEFAULT '', first_date TEXT NOT NULL DEFAULT '', last_date TEXT NOT NULL DEFAULT '', obs INTEGER NOT NULL DEFAULT 1, PRIMARY KEY(base_id,pkey)) WITHOUT ROWID;
CREATE INDEX IF NOT EXISTS idx_plates_last ON plates(base_id,last_date);
CREATE TABLE IF NOT EXISTS observations (base_id INTEGER NOT NULL, pkey TEXT NOT NULL, odate TEXT NOT NULL DEFAULT '', street TEXT NOT NULL DEFAULT '', link TEXT NOT NULL DEFAULT '', vtype TEXT NOT NULL DEFAULT '', ord INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_obs_key ON observations(base_id,pkey);
CREATE TABLE IF NOT EXISTS activities (id TEXT PRIMARY KEY, base_id INTEGER NOT NULL, payload TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_activities_base ON activities(base_id);
`;

const errText=e=>String((e&&(e.message||e.errorMessage))||e);

function getDB(){
 if(!Capacitor.isNativePlatform()) return Promise.reject(new Error('التخزين المحلي يعمل داخل تطبيق Android فقط'));
 if(!dbPromise) dbPromise=(async()=>{
  await sqlite.checkConnectionsConsistency();
  const exists=await sqlite.isConnection(DB_NAME,false);
  const db=exists.result?await sqlite.retrieveConnection(DB_NAME,false):await sqlite.createConnection(DB_NAME,false,'no-encryption',1,false);
  await db.open();
  await db.execute(SCHEMA);
  // تنظيف أي استيراد توقف في النص
  await db.executeSet([
   {statement:'DELETE FROM plates WHERE base_id>=?',values:[STAGE]},
   {statement:'DELETE FROM observations WHERE base_id>=?',values:[STAGE]},
  ],true);
  return db;
 })().catch(e=>{dbPromise=null;throw e;});
 return dbPromise;
}
async function sel(sql,params=[]){const db=await getDB();const r=await db.query(sql,params);return r.values||[];}
async function exec(set){const db=await getDB();await db.executeSet(set,true);}

const COLS='pkey,original,street,link,vtype,first_date,last_date,obs';
const toRec=r=>({key:r.pkey,original:r.original,street:r.street,link:r.link,type:r.vtype,firstDate:r.first_date,lastDate:r.last_date,obs:Number(r.obs)||0});

const digits=s=>String(s??'').replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
function normalize(v){return digits(v).toUpperCase().replace(/[أإآٱ]/g,'ا').replace(/[ىی]/g,'ي').replace(/ة/g,'ه').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/[^\p{L}\p{N}]/gu,'');}
const fmt=n=>new Intl.NumberFormat('ar-SA').format(n||0);

async function countBases(){
 const rs=await sel('SELECT base_id, COUNT(*) AS c FROM plates WHERE base_id IN (1,2) GROUP BY base_id');
 const out={1:0,2:0};rs.forEach(r=>{out[r.base_id]=Number(r.c)||0;});return out;
}
async function countBase(n){const r=await sel('SELECT COUNT(*) AS c FROM plates WHERE base_id=?',[n]);return Number(r[0]?.c)||0;}
async function readStats(n){
 const one=(await sel("SELECT COUNT(*) AS c, COALESCE(SUM(obs),0) AS o, COALESCE(SUM(CASE WHEN obs>1 THEN 1 ELSE 0 END),0) AS r, COUNT(DISTINCT CASE WHEN street<>'' THEN street END) AS s FROM plates WHERE base_id=?",[n]))[0]||{};
 const types=await sel("SELECT CASE WHEN vtype='' THEN 'غير محدد' ELSE vtype END AS name, COUNT(*) AS value FROM plates WHERE base_id=? GROUP BY 1 ORDER BY 2 DESC LIMIT 6",[n]);
 const streets=await sel("SELECT CASE WHEN street='' THEN 'غير محدد' ELSE street END AS name, COUNT(*) AS value FROM plates WHERE base_id=? GROUP BY 1 ORDER BY 2 DESC LIMIT 6",[n]);
 const cut=a=>a.map(x=>({name:String(x.name).length>12?String(x.name).slice(0,12)+'…':String(x.name),value:Number(x.value)}));
 return{unique:Number(one.c)||0,totalObs:Number(one.o)||0,repeated:Number(one.r)||0,streets:Number(one.s)||0,types:cut(types),streetTop:cut(streets)};
}
async function readFilterOptions(n){
 const streets=await sel("SELECT street AS v, COUNT(*) AS c FROM plates WHERE base_id=? AND street<>'' GROUP BY street ORDER BY c DESC LIMIT 200",[n]);
 const types=await sel("SELECT vtype AS v, COUNT(*) AS c FROM plates WHERE base_id=? AND vtype<>'' GROUP BY vtype ORDER BY c DESC LIMIT 100",[n]);
 return{streets:streets.map(x=>x.v),types:types.map(x=>x.v)};
}
function buildWhere({base,search,street,type}){
 const w=['base_id=?'];const p=[base];
 if(search){
  const k=normalize(search);
  const esc=String(search).replace(/[\\%_]/g,m=>'\\'+m);
  w.push("(pkey LIKE ? ESCAPE '\\' OR original LIKE ? ESCAPE '\\')");
  p.push('%'+k+'%','%'+esc+'%');
 }
 if(street){w.push('street=?');p.push(street);}
 if(type){w.push('vtype=?');p.push(type);}
 return{where:w.join(' AND '),params:p};
}
async function queryPage(f,page){
 const{where,params}=buildWhere(f);
 const total=Number((await sel(`SELECT COUNT(*) AS c FROM plates WHERE ${where}`,params))[0]?.c)||0;
 const rs=await sel(`SELECT ${COLS} FROM plates WHERE ${where} ORDER BY last_date DESC, pkey DESC LIMIT ? OFFSET ?`,[...params,PAGE_SIZE,page*PAGE_SIZE]);
 return{rows:rs.map(toRec),total};
}
async function findMany(n,keys){
 const m=new Map();
 for(let i=0;i<keys.length;i+=400){
  const part=keys.slice(i,i+400);
  const rs=await sel(`SELECT ${COLS} FROM plates WHERE base_id=? AND pkey IN (${part.map(()=>'?').join(',')})`,[n,...part]);
  rs.forEach(r=>m.set(r.pkey,toRec(r)));
 }
 return m;
}
async function readObs(n,key){
 const rs=await sel('SELECT odate,street,vtype,link FROM observations WHERE base_id=? AND pkey=? ORDER BY odate DESC,ord DESC LIMIT 200',[n,key]);
 return rs.map(r=>({date:r.odate,street:r.street,type:r.vtype,link:r.link}));
}
async function readNeighbors(n,key){
 const latest=(await sel('SELECT rowid AS rid,odate FROM observations WHERE base_id=? AND pkey=? ORDER BY odate DESC,rowid DESC LIMIT 1',[n,key]))[0];
 if(!latest)return {before:[],after:[]};
 const before=await sel("SELECT p.original,p.vtype,o.odate,o.street,o.link FROM observations o LEFT JOIN plates p ON p.base_id=o.base_id AND p.pkey=o.pkey WHERE o.base_id=? AND (o.odate<? OR (o.odate=? AND o.rowid<?)) ORDER BY o.odate DESC,o.rowid DESC LIMIT 4",[n,latest.odate,latest.odate,latest.rid]);
 const after=await sel("SELECT p.original,p.vtype,o.odate,o.street,o.link FROM observations o LEFT JOIN plates p ON p.base_id=o.base_id AND p.pkey=o.pkey WHERE o.base_id=? AND (o.odate>? OR (o.odate=? AND o.rowid>?)) ORDER BY o.odate ASC,o.rowid ASC LIMIT 4",[n,latest.odate,latest.odate,latest.rid]);
 return {before:before.reverse(),after};
}
async function addActivity(n,text){
 const a={key:Date.now()+'-'+Math.random().toString(36).slice(2,7),base:n,text,at:new Date().toISOString()};
 const db=await getDB();
 await db.run('INSERT INTO activities(id,base_id,payload) VALUES(?,?,?)',[String(a.key),n,JSON.stringify(a)]);
}
async function readActivities(n){
 const rs=await sel('SELECT payload FROM activities WHERE base_id=? ORDER BY id DESC LIMIT 50',[n]);
 return rs.map(x=>JSON.parse(x.payload));
}
async function clearBase(n){
 await exec([
  {statement:'DELETE FROM plates WHERE base_id=?',values:[n]},
  {statement:'DELETE FROM observations WHERE base_id=?',values:[n]},
 ]);
}
async function commitStage(base){
 const s=STAGE+base;
 await exec([
  {statement:'DELETE FROM plates WHERE base_id=?',values:[base]},
  {statement:'DELETE FROM observations WHERE base_id=?',values:[base]},
  {statement:'UPDATE plates SET base_id=? WHERE base_id=?',values:[base,s]},
  {statement:'UPDATE observations SET base_id=? WHERE base_id=?',values:[base,s]},
 ]);
}
const UPSERT="INSERT INTO plates(base_id,pkey,original,street,link,vtype,first_date,last_date,obs) VALUES(?,?,?,?,?,?,?,?,1) ON CONFLICT(base_id,pkey) DO UPDATE SET obs=obs+1, first_date=CASE WHEN first_date='' OR (excluded.first_date<>'' AND excluded.first_date<first_date) THEN excluded.first_date ELSE first_date END, last_date=CASE WHEN excluded.last_date>last_date THEN excluded.last_date ELSE last_date END, street=CASE WHEN excluded.street<>'' AND excluded.last_date>=last_date THEN excluded.street ELSE street END, link=CASE WHEN excluded.link<>'' AND excluded.last_date>=last_date THEN excluded.link ELSE link END, vtype=CASE WHEN excluded.vtype<>'' AND excluded.last_date>=last_date THEN excluded.vtype ELSE vtype END";
const OBS_INSERT='INSERT INTO observations(base_id,pkey,odate,street,link,vtype,ord) VALUES(?,?,?,?,?,?,?)';
async function writeRows(target,rows){
 const set=[];
 for(const r of rows){
  set.push({statement:UPSERT,values:[target,r.key,r.raw,r.street,r.link||'',r.type,r.date,r.date]});
  set.push({statement:OBS_INSERT,values:[target,r.key,r.date,r.street,r.link||'',r.type,r.ord]});
 }
 await exec(set);
}

/* ============================================================
   قراءة الملفات بالتدفق (Streaming)
   ============================================================ */
async function detectEncoding(file){
 const head=new Uint8Array(await file.slice(0,65536).arrayBuffer());
 try{new TextDecoder('utf-8',{fatal:true}).decode(head,{stream:true});return'utf-8';}catch{return'windows-1256';}
}
async function* textChunks(file,enc){
 const reader=file.stream().getReader();const dec=new TextDecoder(enc);let bytes=0;
 for(;;){
  const{done,value}=await reader.read();if(done)break;
  bytes+=value.length;
  yield{text:dec.decode(value,{stream:true}),bytes};
 }
 const tail=dec.decode();if(tail)yield{text:tail,bytes};
}
async function* csvBatches(file){
 const enc=await detectEncoding(file);
 let delim=',',row=[],field='',inQ=false,q=false,first=true;
 for await(const{text:raw,bytes}of textChunks(file,enc)){
  let text=raw;
  if(first){
   first=false;
   if(text.charCodeAt(0)===0xFEFF)text=text.slice(1);
   const nl=text.indexOf('\n');const line=nl<0?text:text.slice(0,nl);
   delim=[',',';','\t'].map(d=>[d,line.split(d).length]).sort((a,b)=>b[1]-a[1])[0][0];
  }
  const out=[];
  for(let i=0;i<text.length;i++){
   const c=text[i];
   if(inQ){
    if(q){
     if(c==='"'){field+='"';q=false;continue;}
     inQ=false;q=false;
    }else{
     if(c==='"'){q=true;continue;}
     field+=c;continue;
    }
   }
   if(c==='"'&&field===''){inQ=true;continue;}
   if(c===delim){row.push(field);field='';continue;}
   if(c==='\n'){
    row.push(field);field='';
    if(!(row.length===1&&row[0]===''))out.push(row);
    row=[];continue;
   }
   if(c==='\r')continue;
   field+=c;
  }
  yield{rows:out,bytes};
 }
 if(field!==''||row.length){row.push(field);yield{rows:[row],bytes:file.size};}
}
async function* sheetBatches(file){
 const buf=await file.arrayBuffer();
 const wb=XLSX.read(buf,{type:'array',dense:true});
 const ws=wb.Sheets[wb.SheetNames[0]];
 const all=XLSX.utils.sheet_to_json(ws,{header:1,raw:false,defval:''});
 if(!all.length)return;
 const head=all[0].map(x=>String(x??''));
 const streetCol=head.findIndex(x=>['الشارع','الموقع','street','location','العنوان'].some(t=>x.toLowerCase().includes(t)));
 const hasLink=head.some(x=>['رابط الموقع','رابط','hyperlink','url','link'].some(t=>x.toLowerCase().includes(t)));
 if(streetCol>=0&&!hasLink){head.push('رابط الموقع');all[0]=head;for(let r=1;r<all.length;r++){const cell=ws[XLSX.utils.encode_cell({r,c:streetCol})];all[r].push(cell?.l?.Target||cell?.l?.target||'');}}
 for(let i=0;i<all.length;i+=2000){
  yield{rows:all.slice(i,i+2000),bytes:Math.round(Math.min(i+2000,all.length)/Math.max(1,all.length)*file.size)};
 }
}
function detectCols(h){
 const find=terms=>h.findIndex(x=>{const s=String(x).replace(/^\uFEFF/,'').trim().toLowerCase();return terms.some(t=>s.includes(t));});
 return{
  plate:find(['اللوحة','الوحه','لوحه','اللوحه','plate','رقم المركبة','رقم اللوحة']),
  date:find(['التاريخ','تاريخ','date','رصد']),
  street:find(['الشارع','الموقع','street','location','العنوان']),
  type:find(['النوع','نوع المركبة','type','vehicle']),
  link:find(['رابط الموقع','رابط','hyperlink','url','link']),
 };
}

/* ===== ملف المطابقة (Excel/CSV) أو اللصق: لوحة + نوع + رقم الشاصيه + الشركة/البنك ===== */
function detectMatchCols(h){
 const find=terms=>h.findIndex(x=>{const s=String(x).replace(/^\uFEFF/,'').trim().toLowerCase().replace(/[\s_-]+/g,' ');return s&&terms.some(t=>s.includes(t));});
 return{
  plate:find(['اللوحة','الوحه','لوحة','لوحه','اللوحه','الوحه','plate number','plate no','license plate','registration number','رقم المركبة','رقم اللوحة','رقم اللوحه','رقم التسجيل']),
  type:find(['النوع','نوع المركبة','نوع','type','vehicle']),
  vin:find(['شاص','شاس','vin','chassis','structure no','هيكل']),
  company:find(['الشركة','الشركه','شركة','شركه','بنك','البنك','bank','company','الجهة','جهة']),
  note:find(['ملاحظ','note','remark']),
 };
}
function findMatchHeader(rows){
 // بعض ملفات الجهات فيها عنوان منفرد للوحة ثم صف العناوين الحقيقي لاحقًا؛ اختر الصف الذي يحتوي أكبر عدد من عناوين الأعمدة.
 let best=null,bestScore=0;
 for(let i=0;i<Math.min(rows.length,40);i++){
  const idx=detectMatchCols(rows[i]||[]);if(idx.plate<0)continue;
  const score=[idx.plate,idx.type,idx.vin,idx.company,idx.note].filter(n=>n>=0).length;
  if(score>bestScore){best={idx,start:i+1,headerFound:true};bestScore=score;}
 }
 if(best)return best;
 return {idx:{plate:0,type:1,vin:2,company:3,note:4},start:0,headerFound:false};
}
function matchLinesFromRows(rows){
 if(!rows.length)return[];
 const {idx,start}=findMatchHeader(rows);
 const g=(r,i)=>i>=0?String(r[i]??'').trim():'';
 const out=[];
 for(let i=start;i<rows.length;i++){
  const r=rows[i],plate=g(r,idx.plate);
  if(!plate)continue;
  // تجاهل صفوف العناوين/الشروحات التي قد تتكرر داخل الملف.
  if(detectMatchCols(r).plate>=0 && /اللوحة|الوحه|plate number|license plate/i.test(r.map(x=>String(x??'')).join(' ')))continue;
  out.push({'اللوحة':plate,'النوع':g(r,idx.type),'VIN':g(r,idx.vin),'الشركة':g(r,idx.company),'الملاحظة':g(r,idx.note),'الترتيب':out.length+1});
 }
 return out;
}
function matchDateValue(value){
 const s=String(value??'').trim();if(!s)return null;
 let m=s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
 if(m){const t=Date.UTC(+m[1],+m[2]-1,+m[3]);return Number.isFinite(t)?t:null;}
 m=s.match(/^(\d{1,2})[\s./-]+(\d{1,2})[\s./-]+(\d{4})/);
 if(m){const a=+m[1],b=+m[2],y=+m[3];const day=a>12?a:b>12?b:a;const month=a>12?b:b>12?a:b;const t=Date.UTC(y,month-1,day);return Number.isFinite(t)?t:null;}
 const t=Date.parse(s);return Number.isFinite(t)?t:null;
}
const parsePasted=text=>matchLinesFromRows(text.split(/\r?\n/).filter(l=>l.trim()).map(l=>l.split('\t')));
async function readMatchFile(file){
 const isCsv=/\.(csv|txt)$/i.test(file.name)||/csv/i.test(file.type||'');
 if(!isCsv&&file.size>MAX_XLSX)throw new Error('BIG_XLSX');
 const rows=[];
 for await(const b of(isCsv?csvBatches(file):sheetBatches(file)))for(const r of b.rows)rows.push(r);
 if(!rows.length)throw new Error('EMPTY');
 if(!findMatchHeader(rows).headerFound)throw new Error('NO_PLATE');
 return matchLinesFromRows(rows);
}

async function runImport({file,isCsv,base,how,dateOverride,onProgress,cancelled}){
 await getDB();
 const target=how==='replace'?STAGE+base:base;
 if(how==='replace')await clearBase(target);
 const before=how==='replace'?0:await countBase(base);
 const now=new Date();const today=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
 const buf=[];let idx=null,total=0,valid=0,lastPct=-1;
 const flush=async()=>{
  if(!buf.length)return;
  await writeRows(target,buf);valid+=buf.length;buf.length=0;
  if(cancelled())throw new Error('CANCELLED');
 };
 try{
  for await(const b of(isCsv?csvBatches(file):sheetBatches(file))){
   for(const r of b.rows){
    if(!idx){idx=detectCols(r);if(idx.plate<0)throw new Error('NO_PLATE');continue;}
    total++;
    const raw=String(r[idx.plate]??'').trim();const key=normalize(raw);
    if(!key)continue;
    buf.push({
     key,raw,
     date:String(dateOverride||(idx.date>=0?String(r[idx.date]??'').trim():'')||today),
     street:idx.street>=0?String(r[idx.street]??'').trim():'',
     link:idx.link>=0?String(r[idx.link]??'').trim():'',
     type:idx.type>=0?String(r[idx.type]??'').trim():'',
     ord:total,
    });
    if(buf.length>=BATCH)await flush();
   }
   const pct=Math.min(98,Math.round(b.bytes/Math.max(1,file.size)*100));
   if(pct!==lastPct){lastPct=pct;onProgress({label:'جاري الاستيراد…',pct,detail:`${fmt(total)} صف تمت قراءته`});}
  }
  await flush();
  if(!idx)throw new Error('EMPTY');
  if(how==='replace'){onProgress({label:'جاري اعتماد القاعدة الجديدة…',pct:99,detail:''});await commitStage(base);}
  const after=await countBase(base);
  const newCount=Math.max(0,after-before);
  return{total,newCount,updated:Math.max(0,valid-newCount)};
 }catch(e){
  if(how==='replace')await clearBase(STAGE+base).catch(()=>{});
  throw e;
 }
}

/* ===== نسخ احتياطي / تصدير بالتدفق إلى ملف ===== */
async function writeChunks(path,gen){
 let first=true;
 for await(const text of gen){
  if(first){await Filesystem.writeFile({path,data:text,directory:Directory.Cache,encoding:Encoding.UTF8,recursive:true});first=false;}
  else await Filesystem.appendFile({path,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
 }
 if(first)await Filesystem.writeFile({path,data:'',directory:Directory.Cache,encoding:Encoding.UTF8,recursive:true});
 return(await Filesystem.getUri({path,directory:Directory.Cache})).uri;
}
const csvCell=v=>{const s=String(v??'');return/[",\n\r]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;};
async function* csvExport(f,onProgress){
 const{where,params}=buildWhere(f);
 yield'\uFEFF'+['اللوحة الأصلية','اللوحة الموحدة','الشارع','رابط الموقع','النوع','أول رصد','آخر رصد','عدد مرات الرصد'].join(',')+'\n';
 let last='',n=0;
 for(;;){
  const rs=await sel(`SELECT ${COLS} FROM plates WHERE ${where} AND pkey>? ORDER BY pkey LIMIT 5000`,[...params,last]);
  if(!rs.length)break;
  yield rs.map(r=>[r.original,r.pkey,r.street,r.link,r.vtype,r.first_date,r.last_date,r.obs].map(csvCell).join(',')).join('\n')+'\n';
  last=rs[rs.length-1].pkey;n+=rs.length;onProgress(n);
 }
}
async function* backupGen(base,onProgress){
 yield JSON.stringify({app:'plates-manager',version:2,base,at:new Date().toISOString()})+'\n';
 let last='',n=0;
 for(;;){
  const rs=await sel(`SELECT ${COLS} FROM plates WHERE base_id=? AND pkey>? ORDER BY pkey LIMIT 3000`,[base,last]);
  if(!rs.length)break;
  yield rs.map(r=>JSON.stringify({t:'p',k:r.pkey,o:r.original,s:r.street,l:r.link,y:r.vtype,f:r.first_date,d:r.last_date,n:r.obs})).join('\n')+'\n';
  last=rs[rs.length-1].pkey;n+=rs.length;onProgress(n);
 }
 let rid=0;
 for(;;){
  const rs=await sel('SELECT rowid AS rid,pkey,odate,street,link,vtype,ord FROM observations WHERE base_id=? AND rowid>? ORDER BY rowid LIMIT 3000',[base,rid]);
  if(!rs.length)break;
  yield rs.map(r=>JSON.stringify({t:'o',k:r.pkey,d:r.odate,s:r.street,l:r.link,y:r.vtype,r:r.ord})).join('\n')+'\n';
  rid=rs[rs.length-1].rid;
 }
}
async function runRestore({file,base,onProgress,cancelled}){
 await getDB();
 const target=STAGE+base;
 await clearBase(target);
 let carry='',head=false,plates=0,obsN=0,buf=[];
 const P='INSERT OR REPLACE INTO plates(base_id,pkey,original,street,link,vtype,first_date,last_date,obs) VALUES(?,?,?,?,?,?,?,?,?)';
 const flush=async()=>{if(buf.length){await exec(buf);buf=[];}if(cancelled())throw new Error('CANCELLED');};
 const handle=async line=>{
  if(!line.trim())return;
  const o=JSON.parse(line);
  if(!head){head=true;if(o.app!=='plates-manager'||o.version!==2)throw new Error('BAD_BACKUP');return;}
  if(o.t==='p'){buf.push({statement:P,values:[target,o.k,o.o||'',o.s||'',o.l||'',o.y||'',o.f||'',o.d||'',Number(o.n)||1]});plates++;}
  else if(o.t==='o'){buf.push({statement:OBS_INSERT,values:[target,o.k,o.d||'',o.s||'',o.l||'',o.y||'',Number(o.r)||0]});obsN++;}
  if(buf.length>=2000)await flush();
 };
 try{
  let lastPct=-1;
  for await(const{text,bytes}of textChunks(file,'utf-8')){
   const parts=(carry+text).replace(/^\uFEFF/,'').split('\n');carry=parts.pop();
   for(const line of parts)await handle(line);
   const pct=Math.min(98,Math.round(bytes/Math.max(1,file.size)*100));
   if(pct!==lastPct){lastPct=pct;onProgress({label:'جاري الاستعادة…',pct,detail:`${fmt(plates)} لوحة`});}
  }
  if(carry.trim())await handle(carry);
  await flush();
  if(!head)throw new Error('BAD_BACKUP');
  onProgress({label:'جاري اعتماد النسخة المستعادة…',pct:99,detail:''});
  await commitStage(base);
  return{plates,obs:obsN};
 }catch(e){
  await clearBase(target).catch(()=>{});
  throw e;
 }
}

/* ============================================================ */
function App(){
 const[base,setBase]=useState(Number(localStorage.getItem('pm-base')||1));
 const[tab,setTab]=useState('home');
 const[save,setSave]=useState('جاري القراءة');
 const[toast,setToast]=useState('');
 const[dbErr,setDbErr]=useState('');
 const[stats,setStats]=useState({unique:0,totalObs:0,repeated:0,streets:0,types:[],streetTop:[]});
 const[baseCounts,setBaseCounts]=useState({1:0,2:0});
 const[activities,setActivities]=useState([]);
 const[report,setReport]=useState(null);
 const[progress,setProgress]=useState(null);
 const[dataVersion,setDataVersion]=useState(0);
 const[listVersion,setListVersion]=useState(0);
 const[search,setSearch]=useState('');
 const[searchQ,setSearchQ]=useState('');
 const[filterType,setFilterType]=useState('');
 const[filterStreet,setFilterStreet]=useState('');
 const[page,setPage]=useState(0);
 const[pageRows,setPageRows]=useState([]);
 const[pageTotal,setPageTotal]=useState(0);
 const[opts,setOpts]=useState({streets:[],types:[]});
 const[matchText,setMatchText]=useState('');
 const[carSearch,setCarSearch]=useState('');
 const[matchBase,setMatchBase]=useState('both');
 const[matchFile,setMatchFile]=useState(null);
 const[dateOverride,setDateOverride]=useState('');
 const[deleteWord,setDeleteWord]=useState('');
 const busyRef=useRef(false);const cancelRef=useRef(false);const staleRef=useRef(false);
 const[busy,setBusy]=useState(false);

 const notify=(t,ms=3500)=>{setToast(t);setTimeout(()=>setToast(''),ms);};
 const startBusy=()=>{busyRef.current=true;cancelRef.current=false;setBusy(true);};
 const endBusy=()=>{busyRef.current=false;setBusy(false);setProgress(null);};
 const dataChanged=()=>{setDataVersion(v=>v+1);setListVersion(v=>v+1);};

 const load=async(n=base)=>{
  // Keep the home screen responsive with very large databases: don't wait for full-table aggregates.
  setSave('جاري القراءة');
  setDbErr('');
  try{
   const countsPromise=countBases();
   const activitiesPromise=readActivities(n);
   setBaseCounts(await countsPromise);
   setActivities(await activitiesPromise);
   staleRef.current=false;setDbErr('');setSave('محفوظ');
   // These aggregate/group-by queries scan hundreds of thousands of rows; run after the UI is painted.
   setTimeout(()=>{
    readStats(n).then(v=>{if(n===base)setStats(v);}).catch(e=>console.error('Home statistics failed:',e));
   },300);
  }catch(e){console.error(e);setDbErr(errText(e));setSave('فشل');}
 };
 useEffect(()=>{localStorage.setItem('pm-base',String(base));setPage(0);setFilterStreet('');setFilterType('');load(base);},[base,dataVersion]);
 useEffect(()=>{if(tab==='home'&&staleRef.current)load(base);},[tab]);
 useEffect(()=>{const t=setTimeout(()=>{setSearchQ(search);setPage(0);},350);return()=>clearTimeout(t);},[search]);
 useEffect(()=>{
  if(tab!=='browse')return;
  let dead=false;
  readFilterOptions(base).then(o=>{if(!dead)setOpts(o);}).catch(e=>console.error(e));
  return()=>{dead=true;};
 },[tab,base,dataVersion]);
 useEffect(()=>{
  if(tab!=='browse')return;
  let dead=false;
  queryPage({base,search:searchQ,street:filterStreet,type:filterType},page)
   .then(r=>{if(!dead){setPageRows(r.rows);setPageTotal(r.total);}})
   .catch(e=>{console.error(e);if(!dead)notify('تعذر قراءة السجلات: '+errText(e),6000);});
  return()=>{dead=true;};
 },[tab,base,searchQ,filterStreet,filterType,page,listVersion]);

 async function importFile(file,how){
  if(!file||busyRef.current)return;
  const isCsv=/\.(csv|txt)$/i.test(file.name)||/csv/i.test(file.type||'');
  if(!isCsv&&file.size>MAX_XLSX){notify('ملف Excel كبير. احفظه بصيغة CSV (UTF-8) وارفعه؛ CSV بيتقرأ بالتدفق ويستحمل مئات الآلاف من الصفوف.',9000);return;}
  startBusy();setReport(null);setProgress({label:'جاري التجهيز…',pct:0,detail:''});
  try{
   const res=await runImport({file,isCsv,base,how,dateOverride,onProgress:setProgress,cancelled:()=>cancelRef.current});
   await addActivity(base,(how==='replace'?'استبدال القاعدة بملف ':'إضافة ملف ')+file.name+` (${fmt(res.total)} صف)`);
   setReport(res);notify('تم الاستيراد بنجاح');dataChanged();
  }catch(e){
   console.error(e);const m=errText(e);
   if(m==='CANCELLED'){notify(how==='replace'?'تم الإيقاف. القاعدة القديمة لم تتغير.':'تم الإيقاف. الصفوف اللي اتكتبت قبل الإيقاف فضلت في القاعدة.',7000);if(how!=='replace')dataChanged();}
   else if(m==='NO_PLATE')notify('مش لاقي عمود للوحة. اسم العمود لازم يحتوي على: اللوحة أو plate',8000);
   else if(m==='EMPTY')notify('الملف مفيهوش صفوف بيانات');
   else notify('فشل الاستيراد: '+m,9000);
   if(how!=='replace'&&m!=='CANCELLED')dataChanged();
  }finally{endBusy();}
 }

 async function loadMatchFile(file){
  if(!file||busyRef.current)return;
  startBusy();setProgress({label:'جاري قراءة ملف المطابقة…',pct:50,detail:file.name});
  try{
   const lines=await readMatchFile(file);
   if(!lines.length){notify('الملف مفيهوش لوحات');return;}
   setMatchFile({name:file.name,lines});setReport(null);notify(`تم تحميل ${fmt(lines.length)} لوحة من الملف`);
  }catch(e){
   const m=errText(e);
   notify(m==='NO_PLATE'?'مش لاقي عمود للوحة. اسم العمود لازم يحتوي على: اللوحة أو plate':m==='BIG_XLSX'?'ملف Excel كبير. احفظه CSV (UTF-8) وارفعه.':m==='EMPTY'?'الملف فاضي':'تعذر قراءة الملف: '+m,8000);
  }finally{endBusy();}
 }
 async function runMatch(){
  const lines=carSearch.trim()?[{'اللوحة':carSearch.trim(),'النوع':'','VIN':'','الشركة':'','الملاحظة':''}]:(matchFile?matchFile.lines:(matchText.trim()?parsePasted(matchText):[]));
  if(!lines.length){notify('الصق اللوحات أو ارفع ملف الأول');return;}
  if(busyRef.current)return;
  startBusy();setSave('جاري المطابقة');
  try{
   const baseIds=matchBase==='both'?[1,2]:[Number(matchBase)];
   const keys=lines.map(l=>normalize(l['اللوحة']));
   const uniq=[...new Set(keys.filter(Boolean))];
   const maps={};
   for(const n of baseIds)maps[n]=await findMany(n,uniq);
   const results=lines.map((q,i)=>({q,key:keys[i],hits:baseIds.map(n=>{const r=maps[n].get(keys[i]);return r?{...r,base:n}:null;}).filter(Boolean)}));
   results.sort((a,b)=>{const ta=Math.max(0,...a.hits.map(h=>matchDateValue(h.lastDate)||0));const tb=Math.max(0,...b.hits.map(h=>matchDateValue(h.lastDate)||0));if(ta&&tb)return tb-ta;if(ta)return -1;if(tb)return 1;return (b.hits.length>0)-(a.hits.length>0)||(a.q['الترتيب']||0)-(b.q['الترتيب']||0);});
   setReport({kind:'match',results,total:lines.length,found:results.filter(x=>x.hits.length).length,missing:results.filter(x=>!x.hits.length).length});
   setSave('محفوظ');
  }catch(e){console.error(e);setSave('فشل');notify('حصل خطأ أثناء المطابقة: '+errText(e),7000);}
  finally{endBusy();}
 }

 const fileCols=x=>({'اللوحة':x.q['اللوحة'],'النوع (الملف)':x.q['النوع']||'','رقم الشاصيه':x.q['VIN']||'','الشركة/البنك':x.q['الشركة']||'','ملاحظة':x.q['الملاحظة']||''});
 const hitCols=x=>({'القاعدة':x.hits.map(h=>h.base===1?'الأولى':'الثانية').join(' / '),'نوع المركبة (القاعدة)':x.hits.map(h=>h.type).join(' / '),'آخر شارع':x.hits.map(h=>h.street).join(' / '),'آخر رصد':x.hits.map(h=>h.lastDate).join(' / '),'مرات الرصد':x.hits.map(h=>h.obs).join(' / ')});
 async function exportMatchReport(){
  if(!report||busyRef.current)return;
  startBusy();setProgress({label:'جاري تجهيز التقرير…',pct:50,detail:''});
  try{
   const found=report.results.filter(x=>x.hits.length),missing=report.results.filter(x=>!x.hits.length);
   if(report.results.length>50000){
    async function* gen(){
     const head=['الحالة','اللوحة','النوع (الملف)','رقم الشاصيه','الشركة/البنك','ملاحظة','القاعدة','نوع المركبة (القاعدة)','آخر شارع','آخر رصد','مرات الرصد'];
     yield'\uFEFF'+head.join(',')+'\n';
     for(let i=0;i<report.results.length;i+=5000){
      yield report.results.slice(i,i+5000).map(x=>{const f=fileCols(x),h=x.hits.length?hitCols(x):{};return[x.hits.length?'موجودة':'غير موجودة',f['اللوحة'],f['النوع (الملف)'],f['رقم الشاصيه'],f['الشركة/البنك'],f['ملاحظة'],h['القاعدة'],h['نوع المركبة (القاعدة)'],h['آخر شارع'],h['آخر رصد'],h['مرات الرصد']].map(csvCell).join(',');}).join('\n')+'\n';
     }
    }
    const path=`match-report-${new Date().toISOString().slice(0,10)}.csv`;
    const uri=await writeChunks(path,gen());
    await Share.share({title:path,text:'تقرير المطابقة',url:uri});
   }else{
    await exportWorkbook('تقرير-المطابقة',[
     ['موجودة',found.map(x=>({...fileCols(x),...hitCols(x)}))],
     ['غير موجودة',missing.map(x=>fileCols(x))],
    ]);
   }
  }catch(e){console.error(e);if(!/cancel|dismiss/i.test(errText(e)))notify('فشل تصدير التقرير: '+errText(e),7000);}
  finally{endBusy();}
 }
 async function shareBase64(data,name,mime){
  try{
   const path='exports/'+name;
   await Filesystem.writeFile({path,data,directory:Directory.Cache,recursive:true});
   const uri=await Filesystem.getUri({path,directory:Directory.Cache});
   await Share.share({title:name,text:'تصدير من منظومة إدارة ومطابقة لوحات السيارات',url:uri.uri,dialogTitle:'مشاركة الملف'});
  }catch(e){
   const blob=new Blob([Uint8Array.from(atob(data),c=>c.charCodeAt(0))],{type:mime});
   const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();URL.revokeObjectURL(a.href);
  }
 }
 async function exportWorkbook(name,sheets){
  const wb=XLSX.utils.book_new();
  for(const[sn,data]of sheets)XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(data),sn);
  const b=XLSX.write(wb,{bookType:'xlsx',type:'base64'});
  await shareBase64(b,name+'.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
 }
 async function exportCSV(){
  if(busyRef.current)return;
  startBusy();setProgress({label:'جاري تجهيز ملف CSV…',pct:0,detail:''});
  try{
   const f={base,search:searchQ,street:filterStreet,type:filterType};
   const path=`plates-base-${base}-${new Date().toISOString().slice(0,10)}.csv`;
   const uri=await writeChunks(path,csvExport(f,n=>setProgress({label:'جاري تجهيز ملف CSV…',pct:Math.min(99,Math.round(n/Math.max(1,pageTotal)*100)),detail:`${fmt(n)} سجل`})));
   await Share.share({title:path,text:'تصدير سجلات القاعدة '+base,url:uri});
  }catch(e){console.error(e);if(!/cancel|dismiss/i.test(errText(e)))notify('فشل التصدير: '+errText(e),7000);}
  finally{endBusy();}
 }
 async function backup(){
  if(busyRef.current)return;
  startBusy();setProgress({label:'جاري إنشاء النسخة الاحتياطية…',pct:0,detail:''});
  try{
   const path=`backup-base-${base}-${new Date().toISOString().slice(0,10)}.jsonl`;
   const uri=await writeChunks(path,backupGen(base,n=>setProgress({label:'جاري إنشاء النسخة الاحتياطية…',pct:Math.min(99,Math.round(n/Math.max(1,stats.unique)*100)),detail:`${fmt(n)} لوحة`})));
   await Share.share({title:path,text:'نسخة احتياطية للقاعدة '+base,url:uri});
  }catch(e){console.error(e);if(!/cancel|dismiss/i.test(errText(e)))notify('فشل النسخ الاحتياطي: '+errText(e),7000);}
  finally{endBusy();}
 }
 async function restore(file){
  if(!file||busyRef.current)return;
  if(!confirm('الاستعادة هتستبدل بيانات القاعدة المفتوحة بالكامل. تكمل؟'))return;
  startBusy();setProgress({label:'جاري التجهيز…',pct:0,detail:''});
  try{
   const res=await runRestore({file,base,onProgress:setProgress,cancelled:()=>cancelRef.current});
   await addActivity(base,`استعادة نسخة احتياطية (${fmt(res.plates)} لوحة)`);
   notify('تمت الاستعادة');dataChanged();
  }catch(e){
   const m=errText(e);
   notify(m==='CANCELLED'?'تم الإيقاف. القاعدة القديمة لم تتغير.':m==='BAD_BACKUP'||/JSON/i.test(m)?'ملف النسخة الاحتياطية غير صالح (لازم يكون .jsonl من النسخة دي)':'فشلت الاستعادة: '+m,8000);
  }finally{endBusy();}
 }
 async function editRecord(r){
  const street=prompt('اكتب اسم الشارع أو الموقع',r.street||'');if(street===null)return;
  const type=prompt('اكتب نوع المركبة',r.type||'');if(type===null)return;
  const date=prompt('اكتب آخر تاريخ رصد (YYYY-MM-DD)',r.lastDate||'');if(date===null)return;
  try{
   await exec([{statement:'UPDATE plates SET street=?,vtype=?,last_date=? WHERE base_id=? AND pkey=?',values:[street,type,date,base,r.key]}]);
   await addActivity(base,'تعديل سجل '+r.original);
   staleRef.current=true;setListVersion(v=>v+1);notify('تم التعديل');
  }catch(e){notify('فشل التعديل: '+errText(e),6000);}
 }
 async function deleteRecord(r){
  if(prompt(`للتأكيد اكتب حذف لحذف اللوحة ${r.original}`)!=='حذف')return;
  try{
   await exec([
    {statement:'DELETE FROM plates WHERE base_id=? AND pkey=?',values:[base,r.key]},
    {statement:'DELETE FROM observations WHERE base_id=? AND pkey=?',values:[base,r.key]},
   ]);
   await addActivity(base,'حذف سجل '+r.original);
   staleRef.current=true;setListVersion(v=>v+1);setBaseCounts(await countBases());notify('تم الحذف');
  }catch(e){notify('فشل الحذف: '+errText(e),6000);}
 }
 async function wipeBase(){
  if(busyRef.current)return;
  startBusy();setProgress({label:'جاري مسح القاعدة…',pct:50,detail:''});
  try{await clearBase(base);await addActivity(base,'مسح القاعدة بالكامل');setDeleteWord('');setReport(null);dataChanged();notify('تم المسح');}
  catch(e){notify('فشل المسح: '+errText(e),6000);}
  finally{endBusy();}
 }

 const nav=[['home','الرئيسية',Home],['upload','رفع',Upload],['add','إضافة',PlusCircle],['match','مطابقة',GitCompare],['browse','استعراض',Search],['security','الأمان',ShieldCheck]];
 const link=r=>r.link?<a href={r.link} target="_blank" rel="noreferrer">{r.street||'فتح الموقع'} <MapPin size={14}/></a>:(r.street||'—');
 const pages=Math.max(1,Math.ceil(pageTotal/PAGE_SIZE));
 const baseName=base===1?'الأولى':'الثانية';

 return <div className="app"><header className="top"><div className="brand"><div className="brandIcon"><Car/></div><div><h1>منظومة إدارة ومطابقة لوحات السيارات</h1><small>{['home','upload','add','browse','security'].includes(tab)?`القاعدة ${baseName}`:'مطابقة بين القواعد'}</small></div></div><div className="saveState"><span className={'dot '+(save==='محفوظ'?'ok':save==='فشل'?'bad':'busy')}></span>{save}</div><div className="bases">{[1,2].map(n=><button key={n} className={base===n?'base active':'base'} disabled={busy} onClick={()=>setBase(n)}><span>القاعدة {n===1?'الأولى':'الثانية'}</span><b>{fmt(baseCounts[n]||0)}</b></button>)}</div></header>
 {dbErr&&<div className="dbError"><b>تعذر الوصول لقاعدة البيانات:</b> {dbErr}<button className="ghost" onClick={()=>load()}>إعادة المحاولة</button></div>}
 {progress&&<div className="progressBox"><b>{progress.label}</b><div className="progressTrack"><div className="progressFill" style={{width:`${progress.pct}%`}}/></div><small>{progress.pct}% {progress.detail}</small><small>سيب الشاشة شغالة لحد ما العملية تخلص.</small><button className="dangerGhost" onClick={()=>{cancelRef.current=true;}}>إيقاف</button></div>}
 <main className="content">{tab==='home'&&<><div className="pageHead"><div><h2>الرئيسية</h2><p>ملخص سريع للبيانات في القاعدة المفتوحة.</p></div><button className="ghost" disabled={busy} onClick={()=>load()}><RefreshCw size={17}/> تحديث</button></div><div className="stats"><Stat icon={Car} title="اللوحات الفريدة" value={stats.unique}/><Stat icon={History} title="إجمالي مرات الرصد" value={stats.totalObs}/><Stat icon={MapPin} title="عدد الشوارع" value={stats.streets}/><Stat icon={RefreshCw} title="نسبة اللوحات المتكررة" value={stats.unique?Math.round(stats.repeated/stats.unique*100)+'%':'0%'}/></div><div className="charts"><ChartCard title="أكثر أنواع المركبات" data={stats.types}/><ChartCard title="أكثر الشوارع" data={stats.streetTop}/></div><section className="panel"><h3>آخر العمليات</h3>{activities.slice(0,6).map(a=><div className="activity" key={a.key}><History size={16}/><span>{a.text}</span><small>{new Date(a.at).toLocaleString('ar-SA')}</small></div>)}{!activities.length&&<Empty text="لسه مفيش عمليات مسجلة."/>}</section></>}
 {['upload','add'].includes(tab)&&<><div className="pageHead"><div><h2>{tab==='upload'?'رفع قاعدة أساسية':'إضافة بيانات جديدة'}</h2><p>{tab==='upload'?'اختار ملف CSV أو Excel عشان تبني القاعدة.':'ضيف ملف فوق البيانات الحالية من غير ما تمسحها.'}</p></div></div>{tab==='upload'&&<div className="warning"><AlertTriangle/> الرفع الأساسي بيستبدل بيانات القاعدة المفتوحة، لكن القاعدة القديمة بتفضل زي ما هي لحد ما الاستيراد يخلص بنجاح. لو فيها بيانات، اعمل نسخة احتياطية الأول.</div>}<section className="panel importPanel"><div className="uploadIcon"><FileSpreadsheet size={32}/></div><h3>اختار ملف البيانات</h3><p>للملفات الكبيرة (مئات الآلاف من اللوحات) استخدم <b>CSV بترميز UTF-8</b>. ملفات Excel مدعومة لحد حوالي 8 ميجا. لازم يكون فيه عمود للوحة.</p><label className="fileButton" style={busy?{opacity:.5,pointerEvents:'none'}:null}>اختيار ملف<input type="file" disabled={busy} accept=".xlsx,.xls,.csv,.txt,text/csv" onChange={e=>{const f=e.target.files?.[0];e.target.value='';importFile(f,tab==='upload'?'replace':'add');}}/></label><label className="fieldLabel">توحيد تاريخ الرصد لكل الصفوف (اختياري)<input type="date" value={dateOverride} onChange={e=>setDateOverride(e.target.value)}/></label>{report&&report.total!==undefined&&report.kind!=='match'&&<div className="reportMini"><b>تقرير آخر ملف</b><span>صفوف مقروءة: {fmt(report.total)}</span><span>لوحات جديدة: {fmt(report.newCount)}</span><span>إضافات رصد: {fmt(report.updated)}</span></div>}</section><section className="panel"><h3>ملاحظات مهمة</h3><ul><li>التكرارات بتتحفظ كمرات رصد إضافية لنفس اللوحة.</li><li>البيانات بتفضل على الجهاز بعد قفل التطبيق.</li><li>الاستيراد الكبير ممكن ياخد عدة دقائق. سيب الشاشة شغالة ومتقفلش التطبيق.</li><li>راجع أسماء الأعمدة في الملف لو اتعرفت البيانات بشكل غير صحيح.</li></ul></section></>}
 {tab==='match'&&<><div className="pageHead"><div><h2>مطابقة اللوحات</h2><p>اختار القاعدة أو القاعدتين، وبعدها الصق اللوحات كل لوحة في سطر.</p></div></div><section className="panel"><label className="fieldLabel">افرز على أي قاعدة؟<select value={matchBase} onChange={e=>setMatchBase(e.target.value)}><option value="1">القاعدة الأولى</option><option value="2">القاعدة الثانية</option><option value="both">القاعدتين معًا</option></select></label><div className="baseCounts"><span>الأولى: {fmt(baseCounts[1])}</span><span>الثانية: {fmt(baseCounts[2])}</span></div><label className="fieldLabel">ابحث عن سيارة بلوحتها مباشرة<input value={carSearch} onChange={e=>{setCarSearch(e.target.value);if(e.target.value.trim()){setMatchFile(null);setMatchText('');}}} placeholder="اكتب رقم اللوحة للبحث السريع"/></label><div className="matchFile"><label className="fileButton" style={busy?{opacity:.5,pointerEvents:'none'}:null}><FileSpreadsheet size={18}/> رفع ملف المطابقة (Excel / CSV)<input type="file" disabled={busy} accept=".xlsx,.xls,.csv,.txt,text/csv" onChange={e=>{const f=e.target.files?.[0];e.target.value='';loadMatchFile(f);}}/></label><small>التطبيق بيدوّر على عنوان عمود اللوحة في أول 40 صف، حتى لو فيه عناوين أو شرح فوقه. يقبل اللوحة أو الوحه أو Plate Number أو License Plate.</small></div>{matchFile?<div className="reportMini"><b>الملف: {matchFile.name}</b><span>{fmt(matchFile.lines.length)} لوحة جاهزة للمطابقة</span><button className="ghost" onClick={()=>{setMatchFile(null);setReport(null);}}>إلغاء الملف واستخدام اللصق</button></div>:<label className="fieldLabel">أو الصق اللوحات هنا (من Excel مباشرة)<textarea rows="7" value={matchText} onChange={e=>setMatchText(e.target.value)} placeholder={'الأفضل تنسخ الأعمدة من Excel مع صف العناوين.\nبدون عناوين الترتيب: لوحة، نوع، شاصيه، شركة/بنك.\n\nأ ب ج 1234'}/></label>}<button className="primary full" disabled={busy} onClick={runMatch}><GitCompare size={18}/> ابدأ المطابقة</button></section>{report?.kind==='match'&&<><div className="stats three"><Stat title="إجمالي المطلوب" value={report.total}/><Stat title="موجودة" value={report.found} good/><Stat title="غير موجودة" value={report.missing} bad/></div>{report.results.length>200&&<div className="warning"><AlertTriangle/> بنعرض أول 200 نتيجة بس على الشاشة. تقرير Excel فيه كل النتائج.</div>}{report.results.filter(x=>x.hits.length).slice(0,200).map((x,i)=><article className="resultCard" key={i}><div className="resultTop"><strong>{x.q['اللوحة']}</strong>{x.hits.length?<span className="pill good">موجودة</span>:<span className="pill bad">غير موجودة</span>}</div>{(x.q['النوع']||x.q['VIN']||x.q['الشركة'])&&<div className="hitGrid fileInfo">{x.q['النوع']&&<span>النوع (الملف)<b>{x.q['النوع']}</b></span>}{x.q['VIN']&&<span>رقم الشاصيه<b>{x.q['VIN']}</b></span>}{x.q['الشركة']&&<span>الشركة/البنك<b>{x.q['الشركة']}</b></span>}</div>}{x.hits.map((r,j)=><div className="hit" key={j}><small>القاعدة {r.base===1?'الأولى':'الثانية'}</small><div className="hitGrid"><span>آخر شارع<b>{link(r)}</b></span><span>آخر رصد<b>{r.lastDate||'—'}</b></span><span>مرات الرصد<b>{fmt(r.obs)}</b></span><span>نوع المركبة (القاعدة)<b>{r.type||'—'}</b></span></div><ObsDetails base={r.base} k={r.key}/><NeighborSightings base={r.base} k={r.key}/></div>)}</article>)}<button className="primary full" disabled={busy} onClick={exportMatchReport}><Download size={18}/> تصدير تقرير {report.results.length>50000?'CSV':'Excel'}</button></>}</>}
 {tab==='browse'&&<><div className="pageHead"><div><h2>استعراض السجلات</h2><p>القاعدة {baseName} — {fmt(pageTotal)} سجل.</p></div><button className="ghost" disabled={busy} onClick={exportCSV}><Download size={17}/> CSV</button></div><input className="searchBox" value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث برقم اللوحة..."/><div className="filters"><select value={filterStreet} onChange={e=>{setFilterStreet(e.target.value);setPage(0);}}><option value="">كل الشوارع</option>{opts.streets.map(s=><option key={s}>{s}</option>)}</select><select value={filterType} onChange={e=>{setFilterType(e.target.value);setPage(0);}}><option value="">كل الأنواع</option>{opts.types.map(s=><option key={s}>{s}</option>)}</select></div><div className="recordList">{pageRows.map(r=><article className="record" key={r.key}><div className="recordHead"><strong>{r.original}</strong><span className="pill">{fmt(r.obs)} رصد</span></div><div className="recordDetails"><span>الشارع<b>{link(r)}</b></span><span>النوع<b>{r.type||'—'}</b></span><span>آخر رصد<b>{r.lastDate||'—'}</b></span></div><div className="actions"><button className="ghost" onClick={()=>editRecord(r)}>تعديل</button><button className="dangerGhost" onClick={()=>deleteRecord(r)}><Trash2 size={15}/> حذف</button></div></article>)}{!pageRows.length&&<Empty text="مفيش سجلات مطابقة للبحث."/>}</div><div className="pagination"><button className="ghost" disabled={page===0} onClick={()=>setPage(p=>p-1)}>السابق</button><span>صفحة {fmt(page+1)} من {fmt(pages)}</span><button className="ghost" disabled={(page+1)*PAGE_SIZE>=pageTotal} onClick={()=>setPage(p=>p+1)}>التالي</button></div></>}
 {tab==='security'&&<><div className="pageHead"><div><h2>الأمان والنسخ الاحتياطي</h2><p>العمليات دي بتأثر على القاعدة {baseName} بس.</p></div></div><section className="panel securityAction"><Database/><div><h3>نسخة احتياطية كاملة</h3><p>ملف JSONL فيه كل سجلات القاعدة ومرات الرصد، بيتكتب على دفعات فيستحمل الأحجام الكبيرة.</p></div><button className="primary" disabled={busy} onClick={backup}><Download size={17}/> نسخ احتياطي</button></section><section className="panel securityAction"><RefreshCw/><div><h3>استعادة نسخة احتياطية</h3><p>اختار ملف .jsonl من نسخة احتياطية عملتها من التطبيق ده.</p></div><label className="fileButton" style={busy?{opacity:.5,pointerEvents:'none'}:null}>اختيار ملف<input type="file" disabled={busy} accept=".jsonl,.json,.txt,application/json,text/plain" onChange={e=>{const f=e.target.files?.[0];e.target.value='';restore(f);}}/></label></section><section className="panel dangerZone"><h3><AlertTriangle/> مسح القاعدة المفتوحة</h3><p>ده هيمسح كل سجلات القاعدة الحالية. اعمل نسخة احتياطية قبل ما تكمل.</p><label className="fieldLabel">اكتب كلمة حذف للتأكيد<input value={deleteWord} onChange={e=>setDeleteWord(e.target.value)} placeholder="حذف"/></label><button className="danger full" disabled={deleteWord!=='حذف'||busy} onClick={wipeBase}><Trash2 size={17}/> مسح القاعدة المفتوحة</button></section><section className="panel"><h3>سجل الأنشطة</h3>{activities.map(a=><div className="activity" key={a.key}><History size={16}/><span>{a.text}</span><small>{new Date(a.at).toLocaleString('ar-SA')}</small></div>)}{!activities.length&&<Empty text="مفيش أنشطة لحد دلوقتي."/>}</section></>}
 </main><nav className="bottomNav">{nav.map(([id,label,Icon])=><button key={id} className={tab===id?'navItem selected':'navItem'} onClick={()=>{setTab(id);setReport(null);}}><Icon size={21}/><span>{label}</span></button>)}</nav>{toast&&<div className="toast"><CheckCircle2 size={18}/>{toast}</div>}</div>;
}
function ObsDetails({base,k}){
 const[open,setOpen]=useState(false);const[rows,setRows]=useState(null);
 useEffect(()=>{if(open&&rows===null)readObs(base,k).then(setRows).catch(()=>setRows([]));},[open]);
 return <details onToggle={e=>setOpen(e.currentTarget.open)}><summary>كل مرات الظهور</summary>{rows===null?(open?<p>جاري التحميل…</p>:null):rows.map((o,i)=><p key={i}>{o.date} — {o.street} — {o.type}</p>)}</details>;
}
function NeighborSightings({base,k}){
 const[rows,setRows]=useState(null);
 useEffect(()=>{let live=true;readNeighbors(base,k).then(v=>{if(live)setRows(v)}).catch(()=>{if(live)setRows({before:[],after:[]})});return()=>{live=false};},[base,k]);
 if(!rows)return <small>جاري تحميل السيارات القريبة من آخر رصد…</small>;
 const all=[...rows.before,...rows.after];
 return <details><summary>٤ سيارات قبل آخر رصد و٤ بعده</summary>{!all.length?<p>مفيش سجلات مجاورة متاحة.</p>:<div>{rows.before.map((x,i)=><p key={'b'+i}>قبل — {x.odate||'بدون تاريخ'} — {x.original||'لوحة غير معروفة'} — {x.street||'بدون شارع'}</p>)}<p><b>آخر رصد للوحة المطلوبة</b></p>{rows.after.map((x,i)=><p key={'a'+i}>بعد — {x.odate||'بدون تاريخ'} — {x.original||'لوحة غير معروفة'} — {x.street||'بدون شارع'}</p>)}</div>}</details>;
}
function Stat({icon:Icon,title,value,good,bad}){return <div className="stat">{Icon&&<div className="statIcon"><Icon size={19}/></div>}<span>{title}</span><strong className={good?'textGood':bad?'textBad':''}>{typeof value==='number'?fmt(value):value}</strong></div>;}
function ChartCard({title,data}){const max=Math.max(1,...data.map(x=>x.value));return <section className="panel chartPanel"><h3>{title}</h3>{data.length?<div className="simpleBars">{data.map((item,i)=><div className="barRow" key={item.name+'-'+i}><div className="barLabel"><span title={item.name}>{item.name}</span><b>{fmt(item.value)}</b></div><div className="barTrack"><div className="barFill" style={{width:`${Math.max(3,item.value/max*100)}%`}}/></div></div>)}</div>:<Empty text="البيانات هتظهر بعد رفع ملف."/>}</section>;}
function Empty({text}){return <div className="empty">{text}</div>;}

createRoot(document.getElementById('root')).render(<App/>);
